window.onload = function(){
    //criar uma nova div com class="nova-div"
    const novaDiv = document.createElement("div")
    novaDiv.classList.add("nova-div");

    const novoH1 = this.document.createElement("h1")
    novoH1.textContent = "Insira abaixo o valores e a descrição:";
    novaDiv.append(novoH1);

    //criar um novo paragrafo(p)
    const novaParang = document.createElement("p");
    novaParang.textContent = "Valores:";

    //inserir o parografo dentro da novaDiv
    novaDiv.append(novaParang);

    const novaParang2 = document.createElement("p2");
    novaParang2.textContent = "Descrição:";

    novaDiv.append(novaParang2);

    //inserir a novaDIv dentro da div conteúdo que já existe!
    const divConteudo = document.getElementById("Conteudo");
    divConteudo.append(novaDiv);

    //evento para o btnsalvar

    const btnSalvar = document.getElementById("btnSalvar");
    btnSalvar.addEventListener('click',function(){
        const texto = document.getElementById("texto");
        const novoP = document.createElement("p");
        novoP.textContent = text.value;

        const painelTextos = document.getElementById("painelTextos");
        painelTextos.append(novoP);
        painelTextos.append(document.createElement("hr"));

        //limpar o textarea
        texto.value = "";
    });
}